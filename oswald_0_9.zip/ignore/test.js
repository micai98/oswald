// - - PREFAB SYSTEM - - 
var prefab_len_last = 0;
var prefab_len_total = 0;
var previous_prefab;

var prefab_chars = {
	// blocks
	"G": o_bl_ground,
	"B": o_bl_brick,
	"C": o_bl_cloud,
	"R": o_bl_cave,
	"W": o_bl_woodenblock,
	"S": o_bl_sand,
	"T": o_bl_tree,
	
	// enemies
	"r": o_enemy_rat,
	"s": o_enemy_spikes,
	"k": o_enemy_cactus,
	
	// bonus
	"c": o_coin,
	"t": o_trampoline,
	
	// vehicles
	"h": o_veh_heli,
	"n": o_sign_noheli
};

function prefab_deploy(px, py, prefab, gap = 0) { 
	console.time("prefab deploy time");
	var content = prefab.content;
	var len = content.length;
	var cx = 0;
	var cy = 0;
	var ce = "";
	prefab_len_last = 0;
	for(i=0; i<=len; i++) {
		ce = content[i]
		if(ce == ".") cx += 1;
		else if (ce == ",") {
			if(cx > prefab_len_last) prefab_len_last = cx;
			cx = 0; 
			cy += 1;
		}
		else if (ce in prefab_chars) {
			prefab_newent(px+cx, py+cy, prefab_chars[ce]);
			cx += 1;
		}
	}
	prefab_len_last += gap;
	prefab_len_total += prefab_len_last;
	prefab_last_empty = false;
	previous_prefab = prefab;
	console.timeEnd("prefab deploy time");
}

function prefab_bank() {
	this.length_min = 3;
	this.length_max = 5;
	this.gap_min = 2;
	this.gap_max = 4;
	this.repeat = true;
	this.start = [];
	this.middle = [];
	this.end = [];
	this.hard = [];
	this.rare = [];
};

function prefab(bank, tags, content) {
	this.bank = bank;
	this.tags = tags;
	this.content = content;
}

// Prefabs

var pr_spawnpoint = new prefab(0, 0, "\
,,,,\
...............c.c.c,\
..............GGGGGGG.,\
..............GGGGGGG.,\
.GGGGGGGGGG...GGGGGGG.,\
.GGGGGGGGGG...GGGGGGG.,\
.GGGGGGGGGG...GGGGGGG.,\
");

var pr_spawnpoint_short = new prefab(0, 0, "\
,,,,,,,\
.GGGGGG,\
.GGGGGG,\
.GGGGGG,\
");



// BEGINNER PREFABS
var pr_beginner_s1 = new prefab(0, 0, "\
,\
,\
,\
,\
,\
,\
...........r,\
.......GGGGG,\
GGGGGGGGGGGG,\
GGGGGGGGGGGG,\
");
var pr_beginner_s2 = new prefab(0, 0, "\
,\
,\
,\
,\
,\
..........r,\
.........WW,\
........WWW,\
GGGGGGGGGGG,\
GGGGGGGGGGG,\
");
var pr_beginner_m1 = new prefab(0, 0, "\
,\
,\
,\
,\
.......c,\
,\
,\
..........GGGGG,\
GGGGG.....GGGGG,\
GGGGG.....GGGGG,\
");
var pr_beginner_m2 = new prefab(0, 0, "\
,\
,\
,\
,\
,\
,\
......WW,\
WW,\
,\
,\
");
var pr_beginner_m3 = new prefab(0, 0, "\
,,,,\
................r,\
..........sGGGGGG..........r,\
......r...GGGGGGG....sGGGGGG,\
sGGGGGG...GGGGGGG....GGGGGGG,\
GGGGGGG...GGGGGGG....GGGGGGG,\
GGGGGGG...GGGGGGG....GGGGGGG,\
");
var pr_beginner_m4 = new prefab(0, 0, "\
............BBBBBBBBBB,\
..................cBBB,\
...................BBB,\
............BBBBB..BBB,\
............BBBc...BBB,\
......BBB...BBB....BBB,\
......BBB...BBB..BBBBB,\
BBB...BBB...BBB,\
BBB...BBB...BBB.................BBB,\
BBB...BBB...BBBBBBBBBBB...BBB...BBB,\
");
var pr_beginner_m5 = new prefab(0, 0, "\
,\
..........c.....c,\
,\
,\
,\
.................GGG,\
.................GGG,\
.................GGG,\
.........t.......GGG,\
GGGGGGGGGGG......GGG..\
");
var pr_beginner_m6 = new prefab(0, 0, "\
................GGG,\
................GGG,\
,\
,\
,\
........c.c.....GGG,\
......sGGGGGs...GGG,\
......GGGGGGG...GGG,\
GGG...GGGGGGG...GGG,\
GGG...GGGGGGG...GGG,\
");
var pr_beginner_m7 = new prefab(0, 0, "\
.............BBBBBBBBBB,\
.............BBBc,\
.............BBB,\
.............BBB..BBBBB,\
.............BBB...cBBB,\
.............BBB....BBB...BBB,\
.............BBBBB..BBB...BBB,\
....................BBB...BBB...BBB,\
BBB.................BBB...BBB...BBB,\
BBB...BBB...BBBBBBBBBBB...BBB...BBB,\
");
var pr_beginner_e1 = new prefab(0, 0, "\
,\
,\
,\
,\
....c,\
,\
....s....,\
....W....,\
GGGGGGGGG,\
GGGGGGGGG,\
");
var pr_beginner_e2 = new prefab(0, 0, "\
,\
,\
,\
,\
,\
............r,\
........GGGGG,\
........GGGGG,\
GGGGG...GGGGG,\
GGGGG...GGGGG,\
");
var pr_beginner_h3 = new prefab(0, 0, "\
,\
,\
,\
,\
,\
,\
,\
,\
GGGGG....t......t.,\
GGGGG....W......W.,\
");
var pr_beginner_h2 = new prefab(0, 0, "\
,\
,\
,\
,\
,\
..........c,\
,\
........W...W,\
GGGGG...W...W...GGGGG,\
GGGGG...W...W...GGGGG,\
");
var pr_beginner_h1 = new prefab(0, 0, "\
,\
,\
,\
,\
............c,\
................W,\
............W...W........r,\
........W...W...W...GGGGGG,\
GGGGG...W...W...W...GGGGGG,\
GGGGG...W...W...W...GGGGGG,\
");

var pr_beginner_r1 = new prefab(0, 0, "\
,\
,\
,\
......................r,\
..................TTTTT,\
....................T,\
........TTTTT.......T..............r,\
..........T.........T........TTTTTTT,\
GGGGG.....T.........T...........T,\
GGGGG.....T.........T...........T.\
");

var pbank_beginner = new prefab_bank();
pbank_beginner.length_min = 3;
pbank_beginner.length_max = 5;
pbank_beginner.gap_min = 3;
pbank_beginner.gap_max = 4;
pbank_beginner.repeat = false;
pbank_beginner.start = [ pr_beginner_s1, pr_beginner_s2 ];
pbank_beginner.middle = [ pr_beginner_m1, pr_beginner_m2, pr_beginner_m3, pr_beginner_m4, pr_beginner_m5, pr_beginner_m6, pr_beginner_m7 ];
pbank_beginner.end = [ pr_beginner_e1, pr_beginner_e2 ];
pbank_beginner.rare = [ pr_beginner_r1 ];
pbank_beginner.hard = [ pr_beginner_h1, pr_beginner_h2, pr_beginner_h3 ];

var pr_castle1_s1 = new prefab(0, 0, "\
............BBBBBBBBBBBBBBBBBBBBBBBB,\
..................cBBB,\
...................BBB,\
............BBBBB..BBB,\
............BBBc...BBB,\
......BBB...BBB....BBB,\
......BBB...BBB..BBBBB,\
BBB...BBB...BBB,\
BBB...BBB...BBB.................BBB,\
BBB...BBB...BBBBBBBBBBB...BBB...BBB,\
");
var pr_castle1_s2 = new prefab(0, 0, "\
.............BBBBBBBBBBBBBBBBBBBBBB,\
.............BBBc...............BBB,\
.............BBB................BBB,\
.............BBB..BBBBB,\
.............BBB...cBBBBBBBBB,\
.............BBB....BBB......,\
.............BBBBB..BBB.........BBB,\
....................BBB.....c...BBB,\
BBB.................BBB...BBB...BBB,\
BBB...BBB...BBBBBBBBBBB...BBB...BBB,\
");
var pr_castle1_s3 = new prefab(0, 0, "\
........BBBBBBBBBBBBBBB,\
.................s,\
................c,\
...............s,\
..........BBBBBBBBBB,\
.................s,\
,\
BBB............s,\
BBB.....BBBBBBBBBBBBBB,\
BBB.....BBBBBBBBBBBBBB,\
");
var pr_castle1_m1 = new prefab(0, 0, "\
BBBBBBBBBBBBBBBBBBB,\
,\
......B.....B,\
....BBBBBBBBBBB,\
,\
,\
.........c,\
BBBBBBssBBBssBBBBBB,\
BBBBBBBBBBBBBBBBBBB,\
BBBBBBBBBBBBBBBBBBB,\
");
var pr_castle1_m2 = new prefab(0, 0, "\
BBBBBBBBBBBBBBBBBBBBBBBBBBBBBB,\
................BB,\
................BB,\
................BB,\
......................BB,\
..........BB..........BB,\
..........BB..........BB......,\
BBBBBB....BB....BB....BB....BB,\
BBBBBB....BB....BB....BB....BB,\
BBBBBB....BB....BB....BB....BB,\
");
var pr_castle1_m3 = new prefab(0, 0, "\
BBBBBBBBBBBBBBBBBBBBBBBBBBB,\
......W......W......W,\
......s......s......s,\
.....................,\
......c......c......c,\
......s.............s,\
......W......s......W,\
......W......W......W,\
BBBBBBBBBBBBBBBBBBBBBBBBBBB,\
BBBBBBBBBBBBBBBBBBBBBBBBBBB,\
");
var pr_castle1_h1 = new prefab(0, 0, "\
BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB,\
......W......W......W..........BB....BB,\
......s......W......s..........BB....BB,\
.............s.................BB....ss,\
......c.............c..........BB......,\
......s......c......s..........ss,\
......W......s......W................BB,\
......W......W......W................BB,\
BBBBBBBBBBBBBBBBBBBBBBBBBBB....BB....BB,\
BBBBBBBBBBBBBBBBBBBBBBBBBBB....BB....BB,\
");
var pbank_castle1 = new prefab_bank();
pbank_castle1.length_min = 1;
pbank_castle1.length_max = 2;
pbank_castle1.gap_min = 3;
pbank_castle1.gap_max = 4;
pbank_castle1.repeat = false;
pbank_castle1.start = [pr_castle1_s1, pr_castle1_s2, pr_castle1_s3];
pbank_castle1.middle = [pr_castle1_m1, pr_castle1_m2, pr_castle1_m3];
pbank_castle1.hard = [pr_castle1_h1];

var pr_heli1_s1 = new prefab(0, 0, "\
,\
,\
,\
,\
,\
,\
,\
.....h,\
GGGGGGG,\
GGGGGGG......,\
");
var pr_heli1_m1 = new prefab(0, 0, "\
.....GGGGG.....GGGGG.....GGGGG,\
.....sssss.....GGGGG.....GGGGG,\
...............GGGGG.....sssss,\
.......c.......GGGGG.....,\
...............sssss.......c,\
.....sssss.....,\
.....GGGGG.......c.......sssss,\
.....GGGGG...............GGGGG,\
.....GGGGG.....sssss.....GGGGG,\
.....GGGGG.....GGGGG.....GGGGG.....,\
");
var pr_heli1_m2 = new prefab(0, 0, "\
....................CCCCCCCC,\
....................CCCCCCCC..........cc.........CCCCCCC,\
.................................................CCCCCCC,\
......CCCCCCCCC,\
......CCCCCCCCC...................CCCCCCCCC,\
..................................CCCCCCCCC,\
..................................................CCCCCCC,\
..................CCCCCC....cc....................CCCCCCC......,\
..................CCCCCC,\
,\
");
var pr_heli1_e1 = new prefab(0, 0, "\
,\
,\
,\
,\
,\
,\
,\
......n,\
....GGGGGGGG,\
....GGGGGGGG,\
");

var pbank_heli1 = new prefab_bank();
pbank_heli1.length_min = 1;
pbank_heli1.length_max = 2;
pbank_heli1.gap_min = 5;
pbank_heli1.gap_max = 7;
pbank_heli1.repeat = true;
pbank_heli1.start = [pr_heli1_s1];
pbank_heli1.middle = [pr_heli1_m1, pr_heli1_m2];
pbank_heli1.end = [pr_heli1_e1];

var prefab_banks = [pbank_beginner, pbank_castle1, pbank_heli1];

var prefab_testing = null;
//var prefab_list = [pr_simple1, pr_simple2, pr_simple3, pr_simple4, pr_simple5, pr_simple6, pr_simple7, pr_simple8, pr_castle1, pr_castle2, pr_castle3, pr_castle4, pr_castle4, pr_castle5, pr_cave2, pr_cave1, pr_cave3, pr_clouds1, pr_clouds2];

var test_prefab = new prefab(0, 0, "\
BBrBGG....,\
GGGGG...sG,\
GGGGG.G.GG,\
");

// - - - - - - - - -