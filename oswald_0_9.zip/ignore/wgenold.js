world_generator_object = this;

prefab_len_total = 0;
prefab_len_last = 0;
this.next_prefab;
this.next_prefab_index = 0;
this.next_bank;
this.next_bank_index = 0;

if(prefab_testing == null) {
	prefab_deploy(0, 0, pr_spawnpoint, 3);
} else {
	prefab_deploy(0, 0, pr_spawnpoint_short, 4);
	prefab_deploy(prefab_len_total, 0, prefab_testing, 4);
}

this.start = null;
this.end = null;
this.rotation = [];
this.bank_rotation = [];

this.bank_rotation_common = [];
this.bank_rotation_uncommon = [];
this.bank_rotation_rare = [];
this.bank_rotation_veryrare = [];

this.current_name = "NO_BANK"
this.current = 0;
this.limit = 0;
this.banksize = 0;
this.repeat = false;
this.min_gap = 1;
this.max_gap = 1;

this.load_bank = function(bank) {
	this.current_name = bank.name;
	this.current = 0;
	this.limit = random_int(bank.length_min, bank.length_max);
	this.repeat = bank.repeat;
	this.rotation = bank.middle.slice();
	this.min_gap = bank.gap_min;
	this.max_gap = bank.gap_max;
	prefab_ceiling = bank.ceiling;
	if(game_expert) this.rotation = this.rotation.concat(bank.hard);
	if(Math.random() < 0.5) this.rotation = this.rotation.concat(bank.rare);
	this.banksize = this.rotation.length;
	if(bank.start.length > 0) this.start = bank.start[random_int(0, bank.start.length-1)];
	if(bank.end.length > 0) this.end = bank.end[random_int(0, bank.end.length-1)];
	previous_bank = bank;
}

this.check_addlist = function() {
	for(var i=0; i<prefab_bank_addlist.length; i++) {
		if(hud_object.score >= prefab_bank_addlist[i][0] && hud_object.score < prefab_bank_addlist[i][1].maxscore && bank_rotation.indexOf(prefab_bank_addlist[i][1]) == -1) {
			this.bank_rotation.push(prefab_bank_addlist[i][1]);
		}
	}
}

this.choose_bank = function() {
	this.skip = false;
	this.iterations = 0;
	this.check_addlist();
	do {
		console.log(this.bank_rotation);
		this.skip = false;
		this.next_bank_index = random_int(0, this.bank_rotation.length-1);
		this.next_bank = this.bank_rotation[this.next_bank_index];
		if(hud_object.score >= this.next_bank.maxscore && this.next_bank.maxscore != -1) { 
			this.bank_rotation.splice(this.next_bank_index, 1);
			this.skip = true;
			console.log("bank expired, skipping and removing from rotation");
		}
		this.iterations += 1;
	} while(this.bank_rotation.length > 1 && this.iterations < 30 && (this.next_bank == previous_bank || this.skip));
	if(!(iterations < 30)) console.log("failsafe triggered");
	this.load_bank(this.next_bank);
}

if(prefab_bank_testing != null) {
	this.load_bank(prefab_bank_testing);
} else this.load_bank(prefab_bank_first);

this.check_addlist();